# Global variables
utils::globalVariables(c("year", "country", "record", "total",
                         "sustainability", "index", "region",
                         "long", "lat", "group", "crop_land",
                         "grazing_land", "forest_land", "fishing_ground",
                         "built_up_land", "total", "indicator_name", "runApp",
                         "shinyApp", "ui", "server"))
