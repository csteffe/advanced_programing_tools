library(testthat)
library(G6)

test_check("G6")
